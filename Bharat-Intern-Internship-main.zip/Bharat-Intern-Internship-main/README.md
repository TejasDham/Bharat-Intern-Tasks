# Bharat-Intern-Internship

TASK : 2

Iris Flowers Classification :

"Predict the different species of flowers on the length of there petals and sepals only colab notebook code."

Dataset : https://drive.google.com/file/d/1BjuNlhtTIvaeOE_Cr_CoHNmHGxHZbzjq/view?usp=sharing


