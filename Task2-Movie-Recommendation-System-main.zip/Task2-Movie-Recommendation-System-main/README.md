# Task2-Movie-Recommendation-System
Built a movie recommendation system using collaborative filtering and machine learning techniques in Python.

Tech Stack: Python, Streamlit, TMDB
